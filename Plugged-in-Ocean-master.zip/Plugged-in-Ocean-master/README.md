Plugged-in-Ocean
================

A set of plugins built upon the Ocean API for the Petrel Software(by Schlumberger)