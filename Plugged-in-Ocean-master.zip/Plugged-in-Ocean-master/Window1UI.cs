using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LogAnalysis
{
    public partial class Window1UI : UserControl
    {
        public Window1UI()
        {
            InitializeComponent();
        }
    }
}
